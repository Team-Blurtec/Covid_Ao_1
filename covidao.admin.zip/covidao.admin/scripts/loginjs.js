$(document).ready(() => {

    let form = $('.ui.form')
    let submitBtn = $('#submitBtn')

    form.form
    (
        {
            inline: true,
            fields: {
                usr: {
                    identifier: 'usr',
                    rules: [
                        {
                            type: 'empty',
                            prompt: '{name}'
                        }
                    ]
                }
            }
        }
    )

    submitBtn.on('click', ev => {

        submitBtn.addClass('loading')


        if (form.form('is valid')) {
            ev.preventDefault()

            $.ajax(
                {
                    type: 'post',
                    url: 'api/ajax.php',
                    dataType: 'html',
                    data: form.serialize()+'&action=login',
                    success: s => {
                        console.log(s)
                        $('#serve').html(s)
                        submitBtn.removeClass('loading')
                    },
                    error: err => {
                        console.log(err)
                    }
                }
            )
        } else {
            submitBtn.removeClass('loading')
        }
    })
})