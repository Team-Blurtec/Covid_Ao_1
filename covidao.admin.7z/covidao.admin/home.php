<?php
?>

<!doctype html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>COVID.AO</title>

    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="lib/semantic-ui/dist/semantic.min.css">
    <link rel="stylesheet" href="lib/sweetalert2/dist/sweetalert2.min.css">

    <style>
        body {
            background-color: #3c3f41 !important;
        }
        .pusher{
            background-color: #3c3f41 !important;
            padding-top: 90px;
        }
    </style>
</head>
<body>

<div class="preload">
    <img src="resources/covidao-vanilla-party.gif" alt="covidao_party_gif">
    <h3>Powered by Blurtec JSKT</h3>
</div>

<div class="ui left thin sidebar vertical inverted labeled icon menu">
    <div class="item">
        <img src="resources/covidao-vanilla-rounds.gif" alt="covidao_fa_gif">
        vijay
    </div>
    <a class="item">
        <i class="yellow home circular icon"></i>
        Iniciar
    </a>
    <a class="item">
        <i class="yellow plus circle circular icon"></i>
        Registar Casos
    </a>
    <a class="item">
        <i class="yellow newspaper circular icon"></i>
        Notícias
    </a>
    <a class="item">
        <i class="yellow user add circular icon"></i>
        Criar Novo Admin
    </a>
    <a class="bottom aligned item">
        <i class="yellow info circular icon"></i>
        Acerca de COVID.AO
    </a>
</div>
<div class="ui borderless inverted basic icon top fixed menu">
    <a id="menuBtn" class="item">
        <i class="big sidebar icon"></i>
    </a>
    <div class="item">
        Iniciar
    </div>
    <a class="ui right item">
        <i class="large yellow sign-out icon"></i>
        &nbsp;Sair
    </a>
</div>
<div class="dimmed pusher">
    <div class="ui container">
        <div class="ui horizontal statistics">
            <div class="ui inverted yellow statistic">
                <div class="value">0 <i class="users icon"></i></div>
                <div class="label">Visitas</div>
            </div>
            <div class="ui inverted yellow statistic">
                <div class="value">0 <i class="down arrow icon"></i></div>
                <div class="label">Downloads</div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="scripts/loaderjs.js"></script>
<script type="text/javascript" src="lib/jquery/dist/jquery.min.js"></script>
<script type="text/javascript" src="lib/semantic-ui/dist/semantic.min.js"></script>
<script type="text/javascript" src="lib/sweetalert2/dist/sweetalert2.all.min.js"></script>
<script type="text/javascript" src="scripts/appjs.js"></script>

<div id="serve"></div>

</body>
</html>