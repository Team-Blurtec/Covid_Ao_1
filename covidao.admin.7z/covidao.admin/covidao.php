<?php
if(isset($_GET['cvao']) && $_GET['cvao'] === '2b'):
?>
<!doctype html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>COVID.AO</title>

    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="lib/semantic-ui/dist/semantic.min.css">
    <link rel="stylesheet" href="lib/sweetalert2/dist/sweetalert2.min.css">

    <style>
        body {
            background-color: #3c3f41;
        }

        body > .grid {
            height: 100%;
        }

        .column {
            max-width: 450px;
        }
    </style>
</head>
<body>
<div class="preload">
    <img src="resources/covidao-vanilla-party.gif" alt="covidao_party_gif">
    <h3>Powered by Blurtec JSKT</h3>
</div>

<div class="ui middle aligned center aligned grid container">
    <div class="blurring column">
        <div class="ui info page dimmer">
            <div class="content">
                <h2 class="ui inverted icon header">
                    <i class="info circle icon"></i>
                    Ocorreu um erro ao submeter o formulário
                </h2>
                <p>Código: a68&c</p>
            </div>
        </div>
        <div class="ui success page dimmer">
            <div class="content">
                <h2 class="ui inverted icon header">
                    <i class="check icon"></i>
                    Conta Criada
                </h2>
                <p>Clica <a href="./">aqui</a> para login ...</p>
            </div>
        </div>
        <div class="ui warning page dimmer">
            <div class="content">
                <h2 class="ui inverted icon header">
                    <i class="exclamation icon"></i>
                    Existe uma conta associada ao nome de utilizador introduzido
                </h2>
                <p>Clica <a href="./">aqui</a> para login ...</p>
            </div>
        </div>
        <div class="ui inverted attached message">
            <div class="header">
                Nova Conta
            </div>
            <p>Preenche devidamente o formulário que se segue</p>
        </div>
        <form class="ui form attached fluid segment" autocomplete="off">
            <div class="field">
                <label>Nome de Utilizador</label>
                <div class="ui left icon labeled input">
                    <i class="user icon"></i>
                    <input name="usr" placeholder="e.x. AgnaldoJS09" type="text">
                    <div class="ui corner label">
                        <i class="asterisk icon"></i>
                    </div>
                </div>
            </div>
            <div class="field">
                <label>Palavra Passe</label>
                <div class="ui left icon labeled input">
                    <i class="lock icon"></i>
                    <input name="psw" placeholder="Palavra Passe" type="password">
                    <div class="ui corner label">
                        <i class="asterisk icon"></i>
                    </div>
                </div>
            </div>
            <div class="field">
                <label>Confirmar a Palavra Passe</label>
                <div class="ui left icon labeled input">
                    <i class="lock icon"></i>
                    <input name="cpsw" placeholder="Introduza novamente..." type="password">
                    <div class="ui corner label">
                        <i class="asterisk icon"></i>
                    </div>
                </div>
            </div>
            <button class="ui large yellow animated fluid button" tabindex="0" id="submeter">
                <div class="visible content"><i class="arrow right icon"></i></div>
                <div class="hidden content">
                    Submeter
                </div>
            </button>
        </form>
        <div class="ui bottom attached warning message">
            <i class="icon help"></i>
            Possui conta? <a href="./">Faça o login</a>.
        </div>
    </div>
</div>

<script type="text/javascript" src="scripts/loaderjs.js"></script>
<script type="text/javascript" src="lib/jquery/dist/jquery.min.js"></script>
<script type="text/javascript" src="lib/semantic-ui/dist/semantic.min.js"></script>
<script type="text/javascript" src="lib/sweetalert2/dist/sweetalert2.all.min.js"></script>
<script type="text/javascript" src="scripts/contajs.js"></script>

<div id="serve"></div>

</body>
</html>
<?php
endif;
?>