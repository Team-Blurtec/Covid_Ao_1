$(document).ready(() => {

    let form = $('.ui.form')
    let submitBtn = $('#submeter')

    form.form
    (
        {
            inline: true,
            on: 'change',
            fields:
                {
                    usr: {
                        identifier: 'usr',
                        rules: [
                            {
                                type: 'empty',
                                prompt: '{name} é um campo obrigatório*'
                            },
                            {
                                type: 'minLength[4]',
                                prompt: '{name} deve conter pelo menos {ruleValue} caracteres*'
                            },
                            {
                                type: 'maxLength[15]',
                                prompt: '{name} tem limite de {ruleValue} caracteres*'
                            }
                        ]
                    },
                    psw: {
                        identifier: 'psw',
                        rules: [
                            {
                                type: 'empty',
                                prompt: '{name} é um campo obrigatório*'
                            },
                            {
                                type: 'minLength[6]',
                                prompt: '{name} deve conter pelo menos {ruleValue} caracteres*'
                            }
                        ]
                    },
                    cpsw: {
                        identifier: 'cpsw',
                        depends: 'psw',
                        rules: [
                            {
                                type: 'match[psw]',
                                prompt: 'A Palavra Passe está incorrecta*'
                            }
                        ]
                    }
                }
        }
    )
    submitBtn.on('click', ev => {

        if (form.form('is valid')){
            ev.preventDefault()

            submitBtn.addClass('loading')

            $.ajax
            (
                {
                    type: 'post',
                    url: 'api/ajax.php',
                    dataType: 'html',
                    data: form.serialize()+'&action=conta',
                    success: s => {
                        console.log(s)

                        submitBtn.removeClass('loading')
                        $('#serve').html(s)
                        form.form('reset')
                    },
                    error: err => {
                        console.log(err)
                        $('.ui.info.dimmer').dimmer('show')
                    }
                }
            )
        }
    })
})