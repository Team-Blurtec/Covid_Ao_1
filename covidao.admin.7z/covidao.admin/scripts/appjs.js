$(document).ready(() => {
    let mb = $('#menuBtn')

    mb.click(() => {
        $('.ui.sidebar').sidebar('toggle')
    })
})