<?php
if (isset($_GET['cvao']) && $_GET['cvao'] === '2b'){
    header('location:covidao.php');
}
?>
<!doctype html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login - COVID.AO</title>

    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="lib/semantic-ui/dist/semantic.min.css">
    <link rel="stylesheet" href="lib/sweetalert2/dist/sweetalert2.min.css">

    <style>
        body {
            background-color: #3c3f41 !important;
        }

        body > .grid {
            height: 100%;
        }

        .image {
            margin-top: -100px;
            height: 100%;
        }

        .column {
            max-width: 450px;
        }
    </style>
</head>
<body>

<div class="preload">
    <img src="resources/covidao-vanilla-party.gif" alt="covidao_party_gif">
    <h3>Powered by Blurtec JSKT</h3>
</div>

<div class="ui middle aligned center aligned grid container">
    <div class="column">
        <h2 class="ui yellow image header">
            <img src="resources/gravity-interwind.gif" alt="covidao_gravity_inter" class="ui big image">
            <div class="content">
                Iniciar Sessão
            </div>
        </h2>
        <form class="ui large form" autocomplete="off">
            <div class="ui stacked segment">
                <div class="field">
                    <div class="ui left icon input">
                        <i class="user icon"></i>
                        <input name="usr" placeholder="ID da Conta" type="text">
                    </div>
                </div>
                <div class="field">
                    <div class="ui left icon input">
                        <i class="lock icon"></i>
                        <input name="psw" placeholder="Palavra Passe" type="password">
                    </div>
                </div>
                <button class="ui large yellow animated fade fluid button" tabindex="0" id="submitBtn" type="submit">
                    <div class="visible content"><i class="sign-in icon"></i></div>
                    <div class="hidden content">
                        Login
                    </div>
                </button>
            </div>

            <div class="ui error message"></div>

        </form>

    </div>
</div>

<script type="text/javascript" src="scripts/loaderjs.js"></script>
<script type="text/javascript" src="lib/jquery/dist/jquery.min.js"></script>
<script type="text/javascript" src="lib/semantic-ui/dist/semantic.min.js"></script>
<script type="text/javascript" src="lib/sweetalert2/dist/sweetalert2.all.min.js"></script>
<script type="text/javascript" src="scripts/loginjs.js"></script>

<div id="serve"></div>

</body>
</html>